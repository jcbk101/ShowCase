package com.genesyseast.showcase;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.widget.SeekBar;

import androidx.appcompat.widget.AppCompatImageView;
import androidx.appcompat.widget.AppCompatSeekBar;

public class StarsEarnedBar
        extends AppCompatSeekBar
{
    private Drawable tickOn;
    private Drawable tickOff;
    private float[]  starsPosi;
    private int      tickWidth;
    private int      tickHeight;
    //
    private boolean  hasResizedProgressBar = false;
    private boolean  hasResizeTickOff      = false;
    private boolean  hasResizeTickOn       = false;
    
    
    /**
     * //#########################################
     * <p>
     * Getters and Setters
     * <p>
     * //#########################################
     *
     * @return
     */
    public Drawable getTickOn()
    {
        return tickOn;
    }
    
    public void setTickOn( Drawable tickOn )
    {
        Bitmap bitmap = drawableToBitmap( tickOn );
        
        if ( tickHeight > 0 && tickWidth > 0 && bitmap != null )
        {
            //            Bitmap   bitmap;
            Drawable newDrawable;
    
            tickWidth = tickHeight = (getHeight() + getHeight() / 2);
            newDrawable = new BitmapDrawable( getResources(), Bitmap.createScaledBitmap( bitmap, tickWidth, tickHeight, true ) );
            
            this.tickOn = newDrawable;
            hasResizeTickOn = true;
        }
        else
        {
            this.tickOn = tickOn;
            hasResizeTickOn = false;
        }
    }
    
    public Drawable getTickOff()
    {
        return tickOff;
    }
    
    public void setTickOff( Drawable tickOff )
    {
        Bitmap bitmap = drawableToBitmap( tickOff );
        
        //        if ( tickHeight > 0 && tickWidth > 0 && bitmap != null )
        if ( getHeight() > 0 && bitmap != null )
        {
            //            Bitmap   bitmap;
            Drawable newDrawable;
            
            //            bitmap = (( BitmapDrawable ) tickOff).getBitmap();
            tickWidth = tickHeight = (getHeight() + getHeight() / 2);
            newDrawable = new BitmapDrawable( getResources(), Bitmap.createScaledBitmap( bitmap, tickWidth, tickHeight, true ) );
            
            this.tickOff = newDrawable;
            hasResizeTickOff = true;
        }
        else
        {
            this.tickOff = tickOff;
            hasResizeTickOff = false;
        }
    }
    
    public float[] getStarsPosi()
    {
        return starsPosi;
    }
    
    public void setStarsPosi( float[] starsPosi )
    {
        this.starsPosi = starsPosi;
    }
    
    public void setStarsPosi( String starsList )
    {
        if ( starsList != null )
        {
            String[] list      = starsList.split( "," );
            float[]  starsPosi = new float[ list.length ];
            
            //
            //#########################
            //
            for ( int i = 0; i < list.length; i++ )
            {
                String num   = list[ i ];
                int    value = Integer.parseInt( num );
                
                starsPosi[ i ] = Math.max( value, 1 );
            }
            
            this.starsPosi = starsPosi;
            
            return;
        }
        
        this.starsPosi = new float[]{ 0, 0, 0 };
    }
    
    /**
     * //###############################
     * <p>
     * Adjust the height according to
     * the view's height, not the PNG
     * <p>
     * //###############################
     *
     * @param d
     */
    @Override
    public void setProgressDrawable( Drawable d )
    {
/*
        Bitmap bitmap = drawableToBitmap( d );
        
        if ( getHeight() > 0 && bitmap != null )
        {
            Drawable newDrawable;
            int      paddingSides  = getPaddingLeft() + getPaddingRight();
            int      paddingTopBot = getPaddingTop() + getPaddingBottom();
            
            //
            newDrawable = new BitmapDrawable( getResources(), Bitmap.createScaledBitmap( bitmap, d.getIntrinsicWidth() - paddingSides, getHeight() - paddingTopBot, true ) );
            
            super.setProgressDrawable( newDrawable );
            hasResizedProgressBar = true;
        }
        else
*/
        {
            super.setProgressDrawable( d );
            hasResizedProgressBar = true;
        }
        
    }
    
    
    public static Bitmap drawableToBitmap( Drawable drawable )
    {
        Bitmap bitmap = null;
        
        if ( drawable != null )
        {
            if ( drawable instanceof BitmapDrawable )
            {
                BitmapDrawable bitmapDrawable = ( BitmapDrawable ) drawable;
                if ( bitmapDrawable.getBitmap() != null )
                {
                    return bitmapDrawable.getBitmap();
                }
            }
            
            if ( drawable.getIntrinsicWidth() <= 0 || drawable.getIntrinsicHeight() <= 0 )
            {
                bitmap = Bitmap.createBitmap( 1, 1, Bitmap.Config.ARGB_8888 ); // Single color bitmap will be created of 1x1 pixel
            }
            else
            {
                bitmap = Bitmap.createBitmap( drawable.getIntrinsicWidth(), drawable.getIntrinsicHeight(), Bitmap.Config.ARGB_8888 );
            }
            
            Canvas canvas = new Canvas( bitmap );
            drawable.setBounds( 0, 0, canvas.getWidth(), canvas.getHeight() );
            drawable.draw( canvas );
            
            return bitmap;
        }
        
        return null;
    }
    
    public int getTickWidth()
    {
        return tickWidth;
    }
    
    public void setTickWidth( int tickWidth )
    {
        this.tickWidth = tickWidth;
    }
    
    public int getTickHeight()
    {
        return tickHeight;
    }
    
    public void setTickHeight( int tickHeight )
    {
        this.tickHeight = tickHeight;
    }
    
    
    /**
     * //#########################################
     * <p>
     * Constructors
     * <p>
     * //#########################################
     *
     * @param context
     */
    public StarsEarnedBar( Context context )
    {
        super( context );
    }
    
    public StarsEarnedBar( Context context, AttributeSet attrs )
    {
        super( context, attrs );
        readAttr( context, attrs );
    }
    
    public StarsEarnedBar( Context context, AttributeSet attrs, int defStyleAttr )
    {
        super( context, attrs, defStyleAttr );
        readAttr( context, attrs );
    }
    
    
    /**
     * //##############################
     * <p>
     * Some Drawables need to be
     * resized
     * <p>
     * //##############################
     *
     * @param canvas
     */
    @Override
    protected synchronized void onDraw( Canvas canvas )
    {
        if ( !hasResizedProgressBar )
        {
            setProgressDrawable( getProgressDrawable() );
        }
        
        if ( !hasResizeTickOn )
        {
            setTickOn( getTickOn() );
        }
        
        if ( !hasResizeTickOff )
        {
            setTickOff( getTickOff() );
        }
        
        super.onDraw( canvas );
        
        drawTickMarks( canvas );
    }
    
    
    /**
     * //############################
     * <p>
     * Class denies access to method
     * <p>
     * //############################
     */
    private void drawTickMarks( Canvas canvas )
    {
        if ( tickOn != null && tickOff != null )
        {
            final int count = starsPosi.length;
            
            if ( count > 1 )
            {
                final int saveCount = canvas.save();
                float     xOffset;
                float     xDiv;
                Drawable  tickMark;
                
                
                //###############################
                //
                //
                //
                //###############################
                for ( int i = 0; i < count; i++ )
                {
                    if ( getProgress() >= starsPosi[ i ] )
                    {
                        tickMark = tickOn;
                    }
                    else
                    {
                        tickMark = tickOff;
                    }
                    
                    //
                    final int w     = tickMark.getIntrinsicWidth();
                    final int h     = tickMark.getIntrinsicHeight();
                    final int halfW = w >= 0 ? w / 2 : 1;
                    final int halfH = h >= 0 ? h / 2 : 1;
                    
                    tickMark.setBounds( -halfW, -halfH, halfW, halfH );
                    
                    // Place the star where it should be on the line
                    xDiv = (( float ) getMax() / ( float ) starsPosi[ i ]);
                    xOffset = (getWidth() - getPaddingLeft() - getPaddingRight()) / xDiv;
                    
                    // Move to the X position for THIS star
                    canvas.translate( getPaddingLeft() + xOffset + (halfW / 2f), getHeight() / 2f );
                    
                    // Draw the star
                    tickMark.draw( canvas );
                    
                    // Reset the Pen's position back to the start
                    // Of the draw location
                    canvas.translate( -(getPaddingLeft() + xOffset + (halfW / 2f)), -(getHeight() / 2f) );
                }
                
                canvas.restoreToCount( saveCount );
            }
        }
    }
    
    
    /**
     * //############################
     * <p>
     * Process atributes
     * <p>
     * //############################
     *
     * @param context
     * @param attrs
     */
    private void readAttr( Context context, AttributeSet attrs )
    {
        TypedArray a = context.obtainStyledAttributes( attrs, R.styleable.StarsEarnedBar );
        int        index;
        Bitmap     bitmap;
        Drawable   newDrawable;
        
        
        //##############################
        //
        // Get the number values
        //
        //##############################
        setTickWidth( a.getDimensionPixelSize( R.styleable.StarsEarnedBar_tickWidth, 0 ) );
        setTickHeight( a.getDimensionPixelSize( R.styleable.StarsEarnedBar_tickHeight, 0 ) );
        //        setMin( a.getInt( R.styleable.StarsEarnedBar_min, 0 ) );
/*
        setMax( a.getInt( R.styleable.StarsEarnedBar_max, 0 ) );
        setProgress( a.getInt( R.styleable.StarsEarnedBar_progress, 0 ) );
*/
        
        
        //##############################
        //
        // GEt the progress drawable to
        // use for progress indicator
        //
        //##############################
        index = a.getResourceId( R.styleable.StarsEarnedBar_progressDrawable, 0 );
        if ( index > 0 )
        {
            setProgressDrawable( getResources().getDrawable( index ) );
        }
        
        
        //##############################
        //
        // Get the tick images
        //
        //##############################
        index = a.getResourceId( R.styleable.StarsEarnedBar_tickMarkOn, 0 );
        if ( index > 0 )
        {
            setTickOn( getResources().getDrawable( index ) );
        }
        
        
        index = a.getResourceId( R.styleable.StarsEarnedBar_tickMarkOff, 0 );
        if ( index > 0 )
        {
            setTickOff( getResources().getDrawable( index ) );
        }
        
        
        //##############################
        //
        // Read the title and set
        // it if any
        //
        //##############################
        String starsList = a.getString( R.styleable.StarsEarnedBar_starPositions );
        
        if ( starsList != null )
        {
            String[] list = starsList.split( "," );
            
            starsPosi = new float[ list.length ];
            
            //
            //#########################
            //
            for ( int i = 0; i < list.length; i++ )
            {
                String num   = list[ i ];
                int    value = Integer.parseInt( num );
                
                if ( value > 0 )
                {
                    // Holds the percentage to divide the
                    // progress width by.
                    // Then the value is the star's X position!
                    //                    starsPosi[ i ] = (( float ) getMax() / ( float ) value);
                    starsPosi[ i ] = value;
                }
                else
                {
                    starsPosi[ i ] = 1;
                }
            }
        }
        
        a.recycle();
    }
    
}
